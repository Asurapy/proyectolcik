A Pen created at CodePen.io. You can find this one at https://codepen.io/clevertechie/pen/NbxyPX.

 Simple account registration form inspired by Blizzard's battle.net with HTML5 validation.