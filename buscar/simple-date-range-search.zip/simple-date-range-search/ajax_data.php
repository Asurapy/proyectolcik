<?php
$date1 = date("Y-m-d", strtotime($_POST['date1']));
$date2 = date("Y-m-d", strtotime($_POST['date2']));

if (!empty($_POST['date1']) and  !empty($_POST['date1'])){
	list($dia,$mes,$anio)=explode("/",$_POST['date1']);
	$date1="$anio-$mes-$dia";
	list($dia,$mes,$anio)=explode("/",$_POST['date2']);
	$date2="$anio-$mes-$dia";
	
	$sWhere="WHERE `date_published` BETWEEN '$date1' AND '$date2'";
	
} else {
	$sWhere="";	
}

#Conectare a la base de datos
include("conexion.php");
	
$q_book = $conn->query("SELECT * FROM `book` $sWhere ORDER BY `title` ASC") or die(mysqli_error());
$v_book = $q_book->num_rows;
if($v_book > 0){
	while($f_book = $q_book->fetch_array()){
	?>
	<tr>
		<td><?php echo $f_book['ISBN']?></td>
		<td><?php echo $f_book['title']?></td>
		<td><?php echo $f_book['author']?></td>
		<td><?php echo date("d/m/Y", strtotime($f_book['date_published']))?></td>
	</tr>
	<?php
	}
}else{
		echo '
		<tr>
			<td colspan = "4" class="text-center">No se encontraron registros</td>
		</tr>
		';
}
	?>