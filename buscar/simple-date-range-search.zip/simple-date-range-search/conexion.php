<?php
$conn = new mysqli("localhost", "root", "", "db_search");
if(!$conn){
	die("Fatal Error: No se pudo contectar a la base de datos!");
}
?>